-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 25, 2025 at 08:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lazydb`
--
CREATE DATABASE IF NOT EXISTS `lazydb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `lazydb`;

-- --------------------------------------------------------

--
-- Table structure for table `my_projects`
--

CREATE TABLE `my_projects` (
  `program_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `program_name` longtext NOT NULL,
  `program_platform` varchar(255) NOT NULL,
  `program_visiblity` varchar(255) NOT NULL,
  `program_type` varchar(255) NOT NULL,
  `program_domains` longtext NOT NULL,
  `program_subdomains` longtext NOT NULL,
  `program_manual_subdomains` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `my_projects`
--

INSERT INTO `my_projects` (`program_id`, `user_id`, `program_name`, `program_platform`, `program_visiblity`, `program_type`, `program_domains`, `program_subdomains`, `program_manual_subdomains`) VALUES
(135, 4, 'loreal-global-private-program', 'YesWeHack', 'Private', 'BBP', '', '', 'nglora.e-loreal.com\r\nwww.loreal-finance.com\r\nwww.loreal.com'),
(136, 4, 'loreal-amer-private-program', 'YesWeHack', 'Private', 'BBP', '', '', 'www.armani-beauty.at\r\nwww.armanibeauty.de\r\nwww.armanibeauty.ch\r\nwww.armanibeauty.it\r\nwww.armanibeauty.co.uk\r\nwww.armanibeauty.fr\r\nwww.armanibeauty.be\r\nwww.armanibeauty.es\r\nwww.armanibeauty.nl\r\nwww.biotherm.de\r\nwww.biotherm.it\r\nwww.biotherm.fr\r\nwww.biotherm.es\r\nwww.carita.co.uk\r\nwww.carita.de\r\nwww.carita.es\r\nwww.carita.it\r\nwww.carita.fr\r\nwww.helenarubinstein.co.uk\r\nwww.helenarubinstein.de\r\nwww.helenarubinstein.fr\r\nwww.helenarubinstein.at\r\nwww.itcosmetics.fr\r\nwww.itcosmetics.de\r\nwww.helenarubinstein.be\r\nwww.helenarubinstein.ch\r\nwww.helenarubinstein.es\r\nwww.helenarubinstein.it\r\nwww.helenarubinstein.nl\r\nwww.kerastase.fr\r\nwww.kerastase.es\r\nwww.kerastase.co.uk\r\nwww.kerastase.de\r\nwww.kerastase.it\r\nwww.kiehls.it\r\nwww.kiehls.se\r\nwww.kiehls.com.tr\r\nwww.kiehls.ch\r\nwww.kiehls.fr\r\nwww.kiehls.co.uk\r\nwww.kiehls.at\r\nwww.kiehls.be\r\nwww.kiehls.bg\r\nwww.kiehls.cz\r\nwww.kiehls.de\r\nwww.kiehls.dk\r\nwww.kiehls.es\r\nwww.kiehls.hr\r\nwww.kiehls.hu\r\nwww.kiehls.ie\r\nwww.kiehls.nl\r\nwww.kiehls.no\r\nwww.kiehls.pl\r\nwww.kiehls.pt\r\nwww.kiehls.ro\r\nwww.kiehls.rs\r\nwww.kiehls.si\r\nwww.kiehls.sk\r\nwww.lancome.co.il\r\nwww.lancome.ie\r\nwww.lancome.co.uk\r\nwww.lancome.fr\r\nwww.lancome.com.tr\r\nwww.lancome.bg\r\nwww.lancome.cz\r\nwww.lancome.de\r\nwww.lancome.es\r\nwww.lancome.hr\r\nwww.lancome.hu\r\nwww.lancome.it\r\nwww.lancome.pl\r\nwww.lancome.nl\r\nwww.lancome.be\r\nwww.lancome.ro\r\nwww.laroche-posay.fr\r\nwww.laroche-posay.co.uk\r\nwww.laroche-posay.ie\r\nwww.loreal-paris.fr\r\nwww.maybelline.de\r\nwww.mugler.fr\r\nwww.mugler.co.uk\r\nwww.nyxcosmetics-nordics.com\r\nwww.nyxcosmetics.co.uk\r\nwww.nyxcosmetics.fr\r\nwww.nyxcosmetics.es\r\nwww.nyxcosmetics.it\r\nwww.skinceuticals.ch\r\nwww.skinceuticals.de\r\nwww.skinceuticals.co.uk\r\nwww.skinceuticals.fr\r\nwww.skinceuticals.it\r\nwww.skinceuticals.nl\r\nwww.skinceuticals.es\r\nwww.urbandecay.co.uk\r\nwww.valentino-beauty.be\r\nwww.valentino-beauty.co.uk\r\nwww.valentino-beauty.fr\r\nwww.valentino-beauty.at\r\nwww.valentino-beauty.de\r\nwww.valentino-beauty.it\r\nwww.valentino-beauty.nl\r\nwww.valentino-beauty.es\r\nwww.valentino-beauty.ch\r\nwww.vichy.co.uk\r\nwww.youthtothepeople.co.uk\r\nwww.yslbeauty.fr\r\nwww.yslbeauty.co.uk\r\nwww.ysl-beauty.be\r\nwww.ysl-beauty.nl\r\nwww.yslbeauty.at\r\nwww.yslbeauty.ch\r\nwww.yslbeauty.de\r\nwww.yslbeauty.es\r\nwww.yslbeauty.it '),
(137, 4, 'synergie-switzerland', 'YesWeHack', 'Private', 'BBP', '', '', 'https://www.sandyou.ch/\r\nhttps://www.synergiesuisse.ch/'),
(138, 4, 'synergie-luxembourg', 'YesWeHack', 'Private', 'BBP', '', '', 'isi.synergie.lu\r\nclip.synergie.lu'),
(139, 4, 'synergie-italia', 'YesWeHack', 'Private', 'BBP', '', '', 'https://www.synergie-italia.it/\r\nhttps://www.sandyou.it/\r\nhttps://www.jobox.it/'),
(140, 4, 'copy-of-synergie-italia', 'YesWeHack', 'Private', 'BBP', '', '', 'portal.synergie-italia.it/\r\nmy.synergie-italia.it/\r\njobslab.org'),
(141, 4, 'pt-nusa-satu-inti-artha-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://dashboard.doku.com/\r\nhttps://jokul.doku.com\r\nhttps://www.doku.com/\r\nhttps://juragan.doku.com/\r\nhttps://api.doku.com/\r\nhttps://pay.doku.com/\r\nhttps://kirimdoku.com/\r\nhttps://my.dokuwallet.com/ '),
(142, 4, 'degica-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://yeswehack-staging.komoju.com\r\nhttps://multipay-staging.test.komoju.com\r\nhttps://doc.komoju.com/docs/fields-overview'),
(143, 4, 'engie-btoc-digital-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'pprodaws.pro.engie.fr\r\nespace-client-pprod.pro.engie.fr'),
(144, 4, 'lalamove-private-program', 'YesWeHack', 'Private', 'BBP', 'lalamove.com', '', 'sg-uapi.lalamove.com\r\nsg-dapi.lalamove.com\r\nweb.lalamove.com'),
(145, 4, 'colas-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.colas.com\r\nhttps://s.www.colas.com\r\nhttps://www.solutions-colas.com\r\nhttps://s.www.solutions-colas.com\r\nhttps://www.spac.fr\r\nhttps://s.www.spac.fr\r\nhttps://www.aximum.com\r\nhttps://www.colasetvous.fr\r\nhttps://cmgo.fr\r\nhttps://colasrail.com '),
(146, 4, 'easyship-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://api.easyship.com\r\nhttps://app.easyship.com\r\nhttps://www.easyship.com\r\nhttps://supership.easyship.com\r\nhttps://trackmyshipment.co\r\nhttps://collect.easyship.com/\r\nhttps://claims.easyship.com/ '),
(147, 4, 'govtech-vrp', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.singpass.gov.sg\r\nhttps://saml.singpass.gov.sg\r\nhttps://bio-stream.singpass.gov.sg\r\nhttps://bio-api.singpass.gov.sg\r\nhttps://api.myinfo.gov.sg\r\nhttps://www.corppass.gov.sg\r\nhttps://service2.mom.gov.sg\r\nhttps://www.mom.gov.sg/\r\nhttps://www.vendors.gov.sg\r\nhttps://www.eld.gov.sg\r\nhttps://app.eservice.eld.gov.sg/\r\nhttps://ntf.singpass.gov.sg\r\nhttps://register.id.gov.sg\r\nhttps://api.id.gov.sg\r\nhttps://vrl.lta.gov.sg\r\nwww.bizfile.gov.sg\r\nhttps://www.tis.bizfile.gov.sg\r\nhttp://www.cdlens.moh.gov.sg/cdlens\r\nhttps://mohalert.moh.gov.sg\r\nhttps://portal.nehr.sg\r\nhttps://mytax.iras.gov.sg/\r\nhttps://www.tradenet.gov.sg\r\nhttps://www.cpf.gov.sg/member/\r\nNS12.GDNSEC.COM\r\nNS9.GDNSEC.COM\r\nNS10.GDNSDEF.COM\r\nNS3.GDNSEC.COM\r\nNS7.GDNSDEF.COM\r\nNS7.GDNSDEF.COM\r\nA1-6.AKAM.NET\r\nA20-66.AKAM.NET\r\nA9-65.AKAM.NET\r\nA8-64.AKAM.NET\r\nA3-67.AKAM.NET\r\nA2-65.AKAM.NET '),
(148, 4, 'land-transport-authority-bug-bounty-program', 'yeswehack', 'Private', 'BBP', 'lta.gov.sg\r\nlta.sg\r\npowereverymove.gov.sg\r\nepscepashub.gov.sg\r\nmybuz.sg\r\nptcareers.gov.sg\r\nonemotoring.sg\r\ntems.sg\r\nonemotoring.gov.sg\r\nonemotoring.com.sg\r\nmytransport.sg ', '', 'www.lta.gov.sg\r\nvrl.lta.gov.sg\r\nprompt.lta.gov.sg\r\ndatamall.lta.gov.sg\r\nonemotoring.lta.gov.sg\r\nocoe.lta.gov.sg\r\nerp.lta.gov.sg\r\nMyTransport.SG\r\nwww.epscepashub.gov.sg\r\nepic.lta.sg\r\n2.tems.sg\r\ntbm2.tems.sg\r\nmonitor2.tems.sg\r\npals.lta.gov.sg\r\napi.insight.lta.gov.sg\r\nportal.insight.lta.gov.sg\r\nignite.lta.gov.sg\r\npbi.insight.lta.gov.sg\r\nvdi2.insight.lta.gov.sg\r\nsurveys.lta.gov.sg'),
(149, 4, 'dnv-private-bug-bounty-program-phast', 'yeswehack', 'Private', 'BBP', '', '', 'https://phast.uat.dnv.com/\r\nhttps://plantwebservices.uat.dnv.com/'),
(150, 4, 'tango-me-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://tango.me/\r\nhttps://gateway.tango.me/'),
(151, 4, 'al-arabiya-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'www.alarabiya.net\r\nenglish.alarabiya.net\r\nfarsi.alarabiya.net\r\nurdu.alarabiya.net\r\nvid.alarabiya.net\r\nmfvip.alarabiya.net\r\nopenapi.alarabiya.net\r\nfeed.alarabiya.net\r\nwabusiness.alarabiya.net '),
(152, 4, 'pixid-2024-clients-eu', 'yeswehack', 'Private', 'BBP', '', '', 'https://test.pixid-services.net\r\nhttps://testapi.mypixid.io\r\nhttps://testwelcome.mypixid.io'),
(153, 4, 'ote-group-cosmote-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.cosmote.gr\r\nhttps://account.cosmote.gr\r\nhttps://www.germanos.gr\r\nhttps://web2sms.cosmote.gr\r\nhttps://talkgroups.cosmote.gr\r\nhttps://iot-portal.cosmote.gr '),
(154, 4, 'onedoc-sa-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.onedoc.ch\r\nhttps://pro.onedoc.ch\r\nhttps://api.onedoc.ch\r\nhttps://telehealth.onedoc.ch '),
(155, 4, 'dpd-ireland-web-and-api-bug-bounty', 'yeswehack', 'Private', 'BBP', '', '', 'https://customsauthorize.dpd.ie\r\nhttps://customspayments.dpd.ie\r\nhttps://manage.dpd.ie\r\nhttps://tracking.dpd.ie\r\nhttps://papi.dpd.ie\r\nhttps://api2.dpd.ie\r\nhttps://dcentral.dpd.ie\r\nhttps://soti.dpd.ie\r\nhttps//depot-webcollections.dpd.ie\r\nhttps://w2.dpd.ie\r\nhttps://my.dpd.ie\r\nhttps://cp.dpd.ie\r\nhttps://vpn2.dpd.ie\r\nhttps://www.dpd.ie '),
(156, 4, 'atg-bug-bounty-program-1', 'yeswehack', 'Private', 'BBP', '', '', 'www.atgtickets.com\r\nauth-service.atgtickets.com\r\nbenefits.core.platform.atgtickets.com\r\nboltapi.atgtickets.com\r\ncalendar-dates-service.atgtickets.com\r\ncalendar-service.core.platform.atgtickets.com\r\ncatalogue-service.atgtickets.com\r\nmanage-account.atgtickets.com\r\npostcode.core.platform.atgtickets.com\r\nsession-service.atgtickets.com\r\nvenue-order-consumer.fb.platform.atgtickets.com\r\nwebsocket-gateway.core.platform.atgtickets.com '),
(157, 4, 'paynet-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://bankweb.fpx.uat.inet.paynet.my\r\nhttps://merchantweb.fpx.uat.inet.paynet.my'),
(158, 4, 'outokumpu-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'www.outokumpu.com\r\nexpertise.outokumpu.com'),
(159, 4, 'lifen', 'yeswehack', 'Private', 'BBP', 'lifen.fr', '', 'app.post-prod.lifen.fr\r\napi-app.public.post-prod.lifen.fr\r\noauth.public.post-prod.lifen.fr\r\nadmin.public.post-prod.lifen.fr\r\nmy.post-prod.lifen.fr\r\nonboarding.public.post-prod.lifen.fr\r\ndashboard.public.post-prod.lifen.fr\r\nauthentication.post-prod.lifen.fr'),
(160, 4, 'sante-publique-france-bugbounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'www.onsexprime.fr\r\nwww.santepubliquefrance.fr\r\nwww.1000-premiers-jours.fr\r\nmangerbouger.fr\r\nsso.mangerbouger.fr\r\nquestionsexualite.fr\r\nexppro.santepubliquefrance.fr\r\nvaccination-info-service.fr\r\nprofessionnels.vaccination-info-service.fr\r\nwww.vivre-avec-la-chaleur.fr\r\ncasa.santepubliquefrance.Fr\r\nwww.tabac-info-service.fr '),
(161, 4, 'digital-matter-bug-bounty-program', 'yeswehack', 'Private', 'BBP', 'digitalmatter.ai\r\ndimatter.ai', '', ''),
(162, 4, 'demo-groupe-seb-bug-bounty-program-template-v2', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.wmf.com'),
(163, 4, 'puma-e-com-website-private-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://uk.puma.com'),
(164, 4, 'pictet-group-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.pictet.com\r\nhttps://am.pictet\r\nhttps://documents.am.pictet/\r\nhttps://pictet.co.jp '),
(165, 4, 'ceva-logistics', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.cevalogistics.com/\r\nhttps://my.cevalogistics.com/'),
(166, 4, 'aia-singapore-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'aia.com.bn\r\naia.com.sg\r\nwww2.aia.com.sg\r\naiafa.com.sg\r\naiaplan360.aia.com.sg\r\naiaplus.aia.com.sg\r\naiaiw.com.sg\r\napigw.aia.com.sg\r\nappsgw.aia.com.sg\r\nchatty.aia.com.sg\r\nclaimez.aia.com.sg\r\ncommunicator.aia.com.sg\r\nconnectingwithaia.aia.com.sg\r\nclaimezapigw.aia.com.sg\r\ndpp.aia.com.sg\r\neben.aia.com.sg\r\nelkapm.aia.com.sg\r\nesign.aia.com.sg\r\ngmd.aia.com.sg\r\nhealthcare.aia.com.sg\r\nicmonline.aia.com.sg\r\nipos.aia.com.bn\r\niposaz.aia.com.sg\r\nishare.aia.com.sg\r\ninsure.aia.com.sg\r\nipos.aia.com.sg\r\nismart.aia.com.sg\r\njoinus.aia.com.sg\r\nmyaia.aia.com.sg\r\nmypageapp.aia.com.sg\r\npar.aia.com.sg\r\npayez2.aia.com.sg\r\nposez.aia.com.sg\r\nqualityhealthcare.aia.com.sg\r\nsigndoc.aia.com.sg\r\ntableau.aia.com.sg\r\nvitalityrace.aia.com.sg\r\nxplore.aia.com.bn\r\nxplore.aia.com.sg\r\nchattyuat.aia.com.sg\r\nclaimezuat.aia.com.sg\r\nebenuat2.aia.com.sg\r\napigwuat.aia.com.sg\r\naiaplan360uat.aia.com.sg\r\naiaplusuat.aia.com.sg\r\nappsgwuat.aia.com.sg\r\nclaimezapigwuat.aia.com.sg\r\ndppuat.aia.com.sg\r\nebenstg.aia.com.sg\r\nelkapmuat.aia.com.sg\r\nesignuat.aia.com.sg\r\ngmduat.aia.com.sg\r\nhealthcareuat.aia.com.sg\r\ninsureuat.aia.com.sg\r\niposuat.aia.com.bn\r\niposuat.aia.com.sg\r\niposazuat.aia.com.sg\r\nishareuat.aia.com.sg\r\nismartuat.aia.com.sg\r\njoinusuat.aia.com.sg\r\nqhcuat.aia.com.sg\r\nparuat.aia.com.sg\r\npayez2uat.aia.com.sg\r\nposezuat.aia.com.sg\r\nsalesuat.aia.com.sg\r\nvitalityraceuat.aia.com.sg\r\nxploreuat.aia.com.bn\r\nxploreuat.aia.com.sg\r\nwwwstg.aiaiw.com.sg\r\nwwwuat.aia.com.bn\r\nwwwuat.aia.com.sg\r\nwwwuat2.aia.com.sg\r\nwww2uat.aia.com.sg\r\nwwwuat.aiafa.com.sg'),
(167, 4, 'pass-culture', 'yeswehack', 'Private', 'BBP', '', '', 'https://app.staging.passculture.team/\r\nhttps://backend.staging.passculture.team/\r\nhttps://pro.staging.passculture.team/ '),
(168, 4, 'ar24-prod-web-app', 'yeswehack', 'Private', 'BBP', '', '', 'https://app.ar24.fr\r\nhttps://sandbox.ar24.fr'),
(169, 4, 'ouestfrance-service-commercial', 'yeswehack', 'Private', 'BBP', '', '', 'https://abonnement.ouest-france.fr/tunnel/\r\nhttps://account-api-abonnement.ingress.prod-k8s.aws.ouest-france.fr/\r\nhttps://votrecompte.ouest-france.fr\r\nhttps://votrecompte.courrierdelouest.fr\r\nhttps://votrecompte.lemainelibre.fr\r\nhttps://votrecompte.presseocean.fr\r\nhttps://moncompte.ouest-france.fr\r\nhttps://account-app-of-et-moi.ouest-france.fr '),
(170, 4, 'pole-emploi-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'mes-aides.francetravail.fr\r\nanotea.francetravail.fr\r\napi2.francetravail.fr\r\nmaformationapi.francetravail.fr\r\napi.francetravail.fr\r\nemploi-store.fr\r\nfrancetravail.io\r\napi.francetravail.io\r\nlabonneboite.francetravail.fr'),
(171, 4, 'citti-handelsgesellschafft-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'lieferanten.citti.de\r\ncittimarkt.de\r\nhoka.dk\r\nshop.chefsculinar.de\r\nshop.chefsculinar.at\r\nshop.chefsculinar.nl\r\nhms-services.com\r\ncitti.de\r\ncitti-park.de\r\ncitti-park-flensburg.de\r\ncitti-park-kiel.de\r\ncitti-park-luebeck.de\r\ncitti-park-rostock.de\r\nstrelapark.de\r\nostseecenter-stralsund.de'),
(172, 4, 'feelunique-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.feelunique.com'),
(173, 4, 'desjardins', 'yeswehack', 'Private', 'BBP', 'employeurd.com\r\ndfsi.ca\r\ndfsin.ca\r\ngestionpriveedesjardins.com\r\ndesjardinscapital.com\r\nassurancevoyagedesjardins.ca\r\nbonidollars.ca\r\nwww.lapersonnelle.com\r\nwww.thepersonal.com\r\nfiduciedesjardins.com\r\nsfl.ca\r\nrcd-dgp.com\r\ndsf-dfs.com\r\nwww.desjardins.com\r\naccesd.mouv.desjardins.com\r\naccesd.affaires.mouv.desjardins.com\r\naccesdc.mouv.desjardins.com\r\naccweb.mouv.desjardins.com\r\nvmdconseil.ca\r\ndesjardinslifeinsurance.com\r\ndesjardinsassurancevie.com\r\ndisnat.com', '', 'www.fondsdesjardins.com\r\nsecure.lapersonnelle-thepersonal.com\r\ntmw.secure.vmd.ca'),
(174, 4, 'thuringer-aufbaubank-bug-bounty-program-legacy', 'yeswehack', 'Private', 'BBP', '', '', 'https://portal.aufbaubank.de'),
(175, 4, 'audioconf', 'yeswehack', 'Private', 'BBP', '', '', 'https://audioconf.incubateur.net'),
(176, 4, 'moncomptepro', 'yeswehack', 'Private', 'BBP', '', '', 'https://app-sandbox.moncomptepro.beta.gouv.fr\r\nhttps://github.com/betagouv/moncomptepro'),
(177, 4, 'labonnealternance', 'yeswehack', 'Private', 'BBP', '', '', 'https://labonnealternance-pentest.apprentissage.beta.gouv.fr\r\nhttps://sentry.apprentissage.beta.gouv.fr\r\nhttps://monitoring.apprentissage.beta.gouv.fr'),
(178, 4, 'mufe-private-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.makeupforever.com/\r\nhttps://www.makeupforever.com/eu/en/morphobeauty'),
(179, 4, 'givenchy-private-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'givenchybeauty.com'),
(180, 4, 'hermes-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'finance.hermes.com\r\nwww.hermes.com\r\necp.hermes.com\r\nbck.hermes.com\r\nwww.fondationdentreprisehermes.org\r\nwww.puiforcat.com'),
(181, 4, 'telefonica', 'yeswehack', 'Private', 'BBP', 'telefonica.com\r\ndigitalsec.telefonica.com \r\ntgies.telefonica.com\r\nglobalsap.telefonica.com', '', 'www.telefonica.es\r\nwww.telefonica.com\r\napis.telefonica.com\r\njobs.telefonica.com\r\nintranet.telefonica.com\r\nsearch.telefonica.com'),
(182, 4, 'copy-of-signet-jewelers', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.banter.com\r\nhttps://stores.banter.com\r\nhttps://credit.kay.com\r\nhttps://credit.jared.com '),
(183, 4, 'profitwell-private-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'www2.profitwell.com\napi.profitwell.com\ndemo.profitwell.com\nretain-api.profitwell.com\nstatic.profitwell.com\nwww.profitwell.com\napi.profitwell-events.com'),
(184, 4, 'paddle-com-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.paddle.com/\r\nhttps://login.paddle.com\r\nhttps://vendors.paddle.com/\r\nhttps://vendors.paddle.com/api/\r\nhttps://sandbox-login.paddle.com\r\nhttps://sandbox-vendors.paddle.com/\r\nhttps://sandbox-vendors.paddle.com/api/\r\nhttps://dashboard-orchestrator.paddle.com/\r\nhttps://sandbox-dashboard-orchestrator.paddle.com/\r\nhttps://api.paddle.com/\r\nhttps://sandbox-api.paddle.com/\r\nhttps://sandbox-checkout.paddle.com/\r\nhttps://sandbox-buy.paddle.com/\r\nhttps://tax-agony.paddle.com/\r\nhttps://developer.paddle.com/'),
(185, 4, 'bursa-malaysia-berhad-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.bursamalaysia.com/\r\nhttps://erapidsystem.bursamalaysia.com\r\nhttps://brc.bursamalaysia.com/\r\nhttps://link.bursamalaysia.com\r\nhttps://bgd-adam.bursamalaysia.com\r\nhttps://pod.bursamarketplace.com\r\nhttps://bgdapi.bursamalaysia.com'),
(186, 4, 'international-committee-of-the-red-cross-icrc-redsafe', 'yeswehack', 'Private', 'BBP', '', '', 'https://redsafe-uat.icrc.org\r\nhttps://auth-uat.icrc.org\r\nhttps://api-uat.icrc.org/dhp/\r\nhttps://api-uat.icrc.org/gisws/'),
(187, 4, 'dbs-wildcard-program', 'yeswehack', 'Private', 'BBP', 'dbs.com', '', 'internet-banking.retail.dbsbank.in\r\ninternet-banking.dbs.com.cn\r\ninternet-banking.hk.dbs.com\r\ninternet-banking.dbs.com.sg\r\ninternet-banking.dbs.com.tw\r\nideal.dbs.com\r\nwww1.dbsvonline.com\r\nddex.dbs.com\r\neli.dbs.com\r\nwww.posb.com.sg\r\ntreasuryprism.dbs.com\r\nhk.warrants.dbs.com\r\ntreasuryprism.dbs.com/\r\nwww.dbs.com.sg'),
(188, 4, 'dbs-ideal', 'yeswehack', 'Private', 'BBP', '', '', 'https://ideal-uat.dbs.com/\r\nhttps://ideal.dbs.com/'),
(189, 4, 'hwcloud', 'yeswehack', 'Private', 'BBP', 'huaweicloud.com', '', ''),
(190, 4, 'swiss-post-self-onboarding-epd', 'yeswehack', 'Private', 'BBP', '', '', 'https://onboarding-preprod.post-sanela.ch\r\nhttps://onboarding.post-sanela.ch'),
(191, 4, 'lombard-odier-cie-sa-bug-bounty-program', 'yeswehack', 'Private', 'BBP', 'lombardodier.com', '', 'https://test.azuretest.lombardodier.com'),
(192, 4, 'stashaway-bug-bounty-program', 'yeswehack', 'Private', 'BBP', 'stashaway.com\r\nstashaway.sg\r\nstashaway.ae\r\nstashaway.hk\r\nstashaway.my\r\nstashaway.co.th', '', 'https://www.stashaway.com\r\nhttps://www.stashaway.sg\r\nhttps://www.stashaway.ae\r\nhttps://www.stashaway.hk\r\nhttps://www.stashaway.my\r\nhttps://www.stashaway.co.th\r\nhttps://api.stashaway.com\r\nhttps://api.stashaway.sg\r\nhttps://api.stashaway.ae\r\nhttps://api.stashaway.hk\r\nhttps://api.stashaway.my\r\nhttps://api.stashaway.co.th\r\nhttps://app.stashaway.com\r\nhttps://app.stashaway.sg\r\nhttps://app.stashaway.ae\r\nhttps://app.stashaway.hk\r\nhttps://app.stashaway.my\r\nhttps://app.stashaway.co.th\r\nhttps://api.production.stashaway.com\r\nhttps://api.production.stashaway.sg\r\nhttps://api.production.stashaway.ae\r\nhttps://api.production.stashaway.hk\r\nhttps://api.production.stashaway.my\r\nhttps://api.production.stashaway.co.th\r\nhttps://whatsapp-connector.production.external.stashaway.sg\r\nhttps://whatsapp-connector.production.external.stashaway.ae\r\nhttps://whatsapp-connector.production.external.stashaway.com\r\nhttps://whatsapp-connector.production.external.stashaway.hk\r\nhttps://whatsapp-connector.production.external.stashaway.my\r\nhttps://whatsapp-connector.production.external.stashaway.co.th\r\nhttps://collect.stashaway.com\r\nhttps://git.stashaway.com\r\nhttps://gitlab.stashaway.com\r\nhttps://registry.stashaway.com\r\nhttps://tracker.stashaway.com\r\nhttps://collector.stashaway.com\r\nhttps://emarsys-connector.production.external.stashaway.com'),
(193, 4, 'louis-vuitton-malletier-corporate-website', 'yeswehack', 'Private', 'BBP', 'louisvuitton.com\r\nlouisvuitton.cn', '', 'https://horizonv2prodapi.azurewebsites.net\r\nhttps://secure.louisvuitton.com\r\nhttps://account.louisvuitton.com\r\nhttps://api.louisvuitton.com\r\nhttps://www.louisvuitton.cn\r\nhttps://secure.louisvuitton.cn\r\nhttps://account.louisvuitton.cn\r\nhttps://api.louisvuitton.cn\r\nhttps://www.louisvuittonwatchprize.com\r\nhttps://www.louisvuittondesigngraduates.com'),
(194, 4, 'exinity-ltd-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://forextime.com\r\nhttps://my.forextime.com'),
(195, 4, 'onfido', 'yeswehack', 'Private', 'BBP', 'onfido.com\r\nonfido.partners', '', 'https://dashboard.eu-west-1.pre-prod.onfido.xyz\r\nhttps://dashboard-api.eu-west-1.pre-prod.onfido.xyz\r\nhttps://onfido-pre-prod.app\r\nhttps://id.eu-west-1.pre-prod.onfido.xyz\r\nhttps://superset.eu-west-1.pre-prod.onfido.xyz'),
(196, 4, 'sephora-bug-bounty-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://www.sephora.fr\r\nhttps://api.sephora.eu\r\nhttps://www.sephora.ae\r\nhttps://www.sephora.de\r\nhttps://www.sephora.com.mx\r\nhttps://www.sephora.com.br'),
(197, 4, 'groupe-la-poste-main-program', 'yeswehack', 'Private', 'BBP', '', '', 'https://toulouselogistiqueurbaine.fr/\r\nhttps://mantis.extra.laposte.fr/\r\nhttps://www.forumgp.extra.laposte.fr/\r\nhttps://www.lapostegroupe.com/\r\nhttps://www.fondationlaposte.org/\r\nhttps://www.vehiposte.fr/\r\nhttps://www.vehipostevo.fr/\r\nhttps://www.vehiparc.fr/\r\nhttps://www.vehiparc.fr/api/mobile\r\nhttps://int.vehiparc.fr/api/mobile\r\nhttps://lapostedulouvre.fr/\r\nhtts://www.laposterecrute.fr/\r\nhttps://www.rh.laposte.fr/\r\nhttps://laposteimmobilier.fr\r\nhttps://immobilier.laposteimmobilier.fr'),
(206, 1, 'F1 Soft BBP', 'Hackerone', 'Private', 'BBP', 'f1soft.com.np', 'https://f1soft.com.np\nhttps://meeting.cp.f1soft.com.np\nhttps://sms.cp.f1soft.com.np\nhttps://sms-report.cp.f1soft.com.np\nhttps://ots.f1soft.com.np\nhttps://hris.f1soft.com.np\nhttps://billpaytest.f1soft.com.np', ''),
(207, 1, 'Esewa BBP', 'Hackerone', 'Public', 'VDP', 'esewa.com.np', 'https://esewa.com.np\nhttps://ir.esewa.com.np\nhttps://cdn-voting.esewa.com.np\nhttps://ir-merchant.esewa.com.np\nhttps://epay.esewa.com.np\nhttps://ceapi-uat.esewa.com.np\nhttps://ceapp-uat.esewa.com.np\nhttps://dev-cdn.esewa.com.np\nhttps://cdn.esewa.com.np\nhttps://ca.esewa.com.np\nhttps://ceapplication-uat.esewa.com.np\nhttps://merchant.esewa.com.np\nhttps://helpdesk.esewa.com.np\nhttps://developer.esewa.com.np\nhttps://org.esewa.com.np\nhttps://presigned.esewa.com.np\nhttps://qadev-org.esewa.com.np\nhttps://qadev.esewa.com.np\nhttps://rc-epay.esewa.com.np\nhttps://reports.esewa.com.np\nhttps://blog.esewa.com.np\nhttps://report.esewa.com.np\nhttps://see.esewa.com.np\nhttps://www.esewa.com.np\nhttps://rc-org.esewa.com.np\nhttps://rc.esewa.com.np', '');

-- --------------------------------------------------------

--
-- Table structure for table `technology_division`
--

CREATE TABLE `technology_division` (
  `technology_id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `technology_name` varchar(255) NOT NULL,
  `total_subs_of_tech_count` int(255) NOT NULL,
  `total_subs_of_tech` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technology_division`
--

INSERT INTO `technology_division` (`technology_id`, `user_id`, `technology_name`, `total_subs_of_tech_count`, `total_subs_of_tech`) VALUES
(1, 4, 'Wordpress', 0, ''),
(114, 4, 'cloudfront', 0, ''),
(118, 1, 'wordpress', 0, ''),
(120, 1, 'cloudfront', 0, ''),
(121, 1, 'php', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `phone_number` text NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `first_name`, `last_name`, `phone_number`, `user_email`, `password`) VALUES
(1, 'root', 'Basant', 'Karki', '9812676664', 'admin@lazydb.ai', 'root'),
(4, 'ajeet0x01', 'Ajeet', 'Karki', '9865636192', 'ajeetkarki@gmail.com', 'ajeet@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `my_projects`
--
ALTER TABLE `my_projects`
  ADD PRIMARY KEY (`program_id`);

--
-- Indexes for table `technology_division`
--
ALTER TABLE `technology_division`
  ADD PRIMARY KEY (`technology_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `my_projects`
--
ALTER TABLE `my_projects`
  MODIFY `program_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `technology_division`
--
ALTER TABLE `technology_division`
  MODIFY `technology_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

--
-- Dumping data for table `pma__export_templates`
--

INSERT INTO `pma__export_templates` (`id`, `username`, `export_type`, `template_name`, `template_data`) VALUES
(1, 'root', 'database', 'lazydb-db-template', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"structure_or_data_forced\":\"0\",\"table_select[]\":[\"my_projects\",\"users\"],\"table_structure[]\":[\"my_projects\",\"users\"],\"table_data[]\":[\"my_projects\",\"users\"],\"aliases_new\":\"\",\"output_format\":\"sendit\",\"filename_template\":\"@DATABASE@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_columns\":\"something\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_columns\":\"something\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"json_structure_or_data\":\"data\",\"json_unicode\":\"something\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Structure of table @TABLE@\",\"latex_structure_continued_caption\":\"Structure of table @TABLE@ (continued)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Content of table @TABLE@\",\"latex_data_continued_caption\":\"Content of table @TABLE@ (continued)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"structure_and_data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"structure_and_data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_use_transaction\":\"something\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_procedure_function\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"xml_structure_or_data\":\"data\",\"xml_export_events\":\"something\",\"xml_export_functions\":\"something\",\"xml_export_procedures\":\"something\",\"xml_export_tables\":\"something\",\"xml_export_triggers\":\"something\",\"xml_export_views\":\"something\",\"xml_export_contents\":\"something\",\"yaml_structure_or_data\":\"data\",\"\":null,\"lock_tables\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"excel_removeCRLF\":null,\"json_pretty_print\":null,\"htmlword_columns\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_create_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_simple_view_export\":null,\"sql_view_current_user\":null,\"sql_or_replace_view\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}'),
(2, 'root', 'server', 'lazydb_db_backup', '{\"quick_or_custom\":\"quick\",\"what\":\"sql\",\"db_select[]\":[\"lazydb\",\"phpmyadmin\",\"test\"],\"aliases_new\":\"\",\"output_format\":\"sendit\",\"filename_template\":\"@SERVER@\",\"remember_template\":\"on\",\"charset\":\"utf-8\",\"compression\":\"none\",\"maxsize\":\"\",\"codegen_structure_or_data\":\"data\",\"codegen_format\":\"0\",\"csv_separator\":\",\",\"csv_enclosed\":\"\\\"\",\"csv_escaped\":\"\\\"\",\"csv_terminated\":\"AUTO\",\"csv_null\":\"NULL\",\"csv_columns\":\"something\",\"csv_structure_or_data\":\"data\",\"excel_null\":\"NULL\",\"excel_columns\":\"something\",\"excel_edition\":\"win\",\"excel_structure_or_data\":\"data\",\"json_structure_or_data\":\"data\",\"json_unicode\":\"something\",\"latex_caption\":\"something\",\"latex_structure_or_data\":\"structure_and_data\",\"latex_structure_caption\":\"Structure of table @TABLE@\",\"latex_structure_continued_caption\":\"Structure of table @TABLE@ (continued)\",\"latex_structure_label\":\"tab:@TABLE@-structure\",\"latex_relation\":\"something\",\"latex_comments\":\"something\",\"latex_mime\":\"something\",\"latex_columns\":\"something\",\"latex_data_caption\":\"Content of table @TABLE@\",\"latex_data_continued_caption\":\"Content of table @TABLE@ (continued)\",\"latex_data_label\":\"tab:@TABLE@-data\",\"latex_null\":\"\\\\textit{NULL}\",\"mediawiki_structure_or_data\":\"data\",\"mediawiki_caption\":\"something\",\"mediawiki_headers\":\"something\",\"htmlword_structure_or_data\":\"structure_and_data\",\"htmlword_null\":\"NULL\",\"ods_null\":\"NULL\",\"ods_structure_or_data\":\"data\",\"odt_structure_or_data\":\"structure_and_data\",\"odt_relation\":\"something\",\"odt_comments\":\"something\",\"odt_mime\":\"something\",\"odt_columns\":\"something\",\"odt_null\":\"NULL\",\"pdf_report_title\":\"\",\"pdf_structure_or_data\":\"data\",\"phparray_structure_or_data\":\"data\",\"sql_include_comments\":\"something\",\"sql_header_comment\":\"\",\"sql_use_transaction\":\"something\",\"sql_compatibility\":\"NONE\",\"sql_structure_or_data\":\"structure_and_data\",\"sql_create_table\":\"something\",\"sql_auto_increment\":\"something\",\"sql_create_view\":\"something\",\"sql_create_trigger\":\"something\",\"sql_backquotes\":\"something\",\"sql_type\":\"INSERT\",\"sql_insert_syntax\":\"both\",\"sql_max_query_size\":\"50000\",\"sql_hex_for_binary\":\"something\",\"sql_utc_time\":\"something\",\"texytext_structure_or_data\":\"structure_and_data\",\"texytext_null\":\"NULL\",\"yaml_structure_or_data\":\"data\",\"\":null,\"as_separate_files\":null,\"csv_removeCRLF\":null,\"excel_removeCRLF\":null,\"json_pretty_print\":null,\"htmlword_columns\":null,\"ods_columns\":null,\"sql_dates\":null,\"sql_relation\":null,\"sql_mime\":null,\"sql_disable_fk\":null,\"sql_views_as_tables\":null,\"sql_metadata\":null,\"sql_drop_database\":null,\"sql_drop_table\":null,\"sql_if_not_exists\":null,\"sql_simple_view_export\":null,\"sql_view_current_user\":null,\"sql_or_replace_view\":null,\"sql_procedure_function\":null,\"sql_truncate\":null,\"sql_delayed\":null,\"sql_ignore\":null,\"texytext_columns\":null}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data for table `pma__recent`
--

INSERT INTO `pma__recent` (`username`, `tables`) VALUES
('root', '[{\"db\":\"lazydb\",\"table\":\"users\"},{\"db\":\"lazydb\",\"table\":\"my_projects\"},{\"db\":\"lazydb\",\"table\":\"technology_division\"}]');

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data for table `pma__table_uiprefs`
--

INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'lazydb', 'my_projects', '{\"sorted_col\":\"`my_projects`.`program_manual_subdomains` ASC\",\"CREATE_TIME\":\"2025-01-20 21:24:34\"}', '2025-01-23 07:43:28'),
('root', 'lazydb', 'technology_division', '{\"sorted_col\":\"`technology_name` ASC\"}', '2025-01-20 16:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2025-01-25 07:21:46', '{\"Console\\/Mode\":\"collapse\",\"NavigationWidth\":319}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Database: `test`
--
CREATE DATABASE IF NOT EXISTS `test` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `test`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
